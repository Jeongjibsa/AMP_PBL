package com.hansung.amp_shoppingmall;

public class Data {

    private String smallClass;
    private String bigClass;
    private String stock;
    private String productName;
    private String productPrice;
    private int imgId;

    public String getSmallClass() {
        return smallClass;
    }

    public String getBigClass() {
        return bigClass;
    }

    public String getStock() {
        return stock;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public int getImgId() {
        return imgId;
    }

    public void setSmallClass(String smallClass) {
        this.smallClass = smallClass;
    }

    public void setBigClass(String bigClass) {
        this.bigClass = bigClass;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }
}