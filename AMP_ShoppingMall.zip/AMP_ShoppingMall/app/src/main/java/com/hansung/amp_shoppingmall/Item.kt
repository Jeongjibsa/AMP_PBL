package com.hansung.amp_shoppingmall

class Item (val productName: String,
            val itemName: String,
            val itemPrice: String,
            val itemBigClass: String,
            val itemSmallClass: String,
            val itemStock: String)